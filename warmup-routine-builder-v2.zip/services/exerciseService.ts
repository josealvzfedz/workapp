import { Exercise, DbExercise, ExerciseType, Language } from '../types';
import { getPredefinedExercises } from '../constants';

// Cache to store the fetched and adapted exercises for each language.
const exerciseCache = new Map<Language, Exercise[]>();

/**
 * Adapts an exercise from the raw database format to the application's unified Exercise format.
 * - Adds a 'db_' prefix to the ID to prevent collisions.
 * - Joins instruction steps into a single description string.
 * - Constructs full, valid URLs for images.
 * - Assigns default timing properties to make it compatible with the routine player.
 * @param dbExercise The raw exercise object from the JSON file.
 * @returns An Exercise object ready to be used in the application.
 */
const adaptDbExercise = (dbExercise: DbExercise): Exercise => {
  const GITHUB_IMAGE_BASE_URL = 'https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises/';
  
  const description = dbExercise.instructions.join('\n');
  const imageUrl = dbExercise.images && dbExercise.images.length > 0 ? `${GITHUB_IMAGE_BASE_URL}${dbExercise.images[0]}` : undefined;
  const images = dbExercise.images ? dbExercise.images.map(img => `${GITHUB_IMAGE_BASE_URL}${img}`) : [];

  // Add default timing to make it compatible with the routine system
  const defaultTiming = {
    type: ExerciseType.BLOCK,
    duration: 30,
    reps: 1,
    restBetweenReps: 0,
  };

  return {
    ...dbExercise,
    id: `db_${dbExercise.id}`, // Prefix to avoid ID collisions
    description,
    imageUrl,
    images,
    ...defaultTiming,
  };
};

/**
 * Asynchronously fetches and prepares the database exercises for a specific language.
 * Uses a cache to avoid re-fetching the data on subsequent calls.
 * @param language The desired language ('en' or 'es').
 * @returns A promise that resolves to an array of adapted Exercise objects.
 */
const getDbExercises = async (language: Language): Promise<Exercise[]> => {
  if (exerciseCache.has(language)) {
    return exerciseCache.get(language)!;
  }
  try {
    const response = await fetch(`../data/exercises-${language}.json`);
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    const jsonData = await response.json();
    const dbData = (jsonData.exercises || []) as DbExercise[];
    const adaptedExercises = dbData.map(adaptDbExercise);
    exerciseCache.set(language, adaptedExercises);
    return adaptedExercises;
  } catch (error) {
    console.error(`Failed to fetch or process exercises-${language}.json:`, error);
    throw error; // Re-throw to allow UI to handle it
  }
};

/**
 * Retrieves a combined and sorted list of all available exercises for a given language.
 * @param userCustomExercises An array of exercises created by the user.
 * @param language The desired language ('en' or 'es').
 * @returns A Promise that resolves to a single, sorted array of all exercises.
 */
const getAllExercises = async (userCustomExercises: Exercise[] = [], language: Language): Promise<Exercise[]> => {
  const predefinedExercises = getPredefinedExercises(language);
  const adaptedDbExercises = await getDbExercises(language);

  // Note: userCustomExercises are not translated statically as they are user-generated.
  const all = [...predefinedExercises, ...adaptedDbExercises, ...userCustomExercises];
  
  // Sort alphabetically for a better user experience in the search list
  return all.sort((a, b) => a.name.localeCompare(b.name));
};

export const exerciseService = {
  getAllExercises,
};
