import { GoogleGenAI } from '@google/genai';
import { Language } from '../types';

// Simple in-memory cache to avoid re-translating the same text
const translationCache = new Map<string, string>();

/**
 * Translates a given text to the target language using the Gemini API.
 * Caches results to avoid redundant API calls.
 * @param text The text to translate.
 * @param targetLanguage The target language ('en' or 'es').
 * @returns A promise that resolves to the translated text.
 */
const translate = async (text: string, targetLanguage: Language): Promise<string> => {
    if (!text || targetLanguage === 'en') {
        return text; // Don't translate empty strings or if the target is English
    }

    const cacheKey = `${targetLanguage}::${text}`;
    if (translationCache.has(cacheKey)) {
        return translationCache.get(cacheKey)!;
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
        const model = 'gemini-2.5-flash';
        
        const langName = targetLanguage === 'es' ? 'Spanish' : 'English';

        const prompt = `Translate the following fitness exercise description into ${langName}. Return ONLY the translated text, without any introductory phrases, labels, or markdown formatting:\n\n"${text}"`;

        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
        });

        const translatedText = response.text.trim();
        translationCache.set(cacheKey, translatedText);
        return translatedText;
    } catch (error) {
        console.error("Translation failed:", error);
        // Fallback to the original text if translation fails
        return text;
    }
};

export const translationService = {
    translate,
};
