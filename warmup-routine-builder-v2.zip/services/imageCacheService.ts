import { GoogleGenAI, Modality } from '@google/genai';
import { Exercise } from '../types';

const DB_NAME = 'warmup-routine-builder-db';
const STORE_NAME = 'generated-images';
const DB_VERSION = 1;

let db: IDBDatabase | null = null;

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (db) {
      resolve(db);
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject("Error opening IndexedDB.");
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };
    request.onupgradeneeded = (event) => {
      const dbInstance = (event.target as IDBOpenDBRequest).result;
      if (!dbInstance.objectStoreNames.contains(STORE_NAME)) {
        dbInstance.createObjectStore(STORE_NAME, { keyPath: 'exerciseId' });
      }
    };
  });
};

const getImageFromCache = async (exerciseId: string): Promise<string | null> => {
    const db = await openDB();
    return new Promise((resolve) => {
        const transaction = db.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.get(exerciseId);
        request.onsuccess = () => {
            resolve(request.result?.imageData || null);
        };
        request.onerror = () => {
            console.error(`Error fetching image from cache for ${exerciseId}`);
            resolve(null);
        };
    });
};

const saveImageToCache = async (exerciseId: string, imageData: string): Promise<void> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.put({ exerciseId, imageData });
        request.onsuccess = () => resolve();
        request.onerror = (event) => {
            console.error(`Failed to save image to cache for ${exerciseId}:`, (event.target as IDBRequest).error);
            reject("Failed to save image to cache.");
        }
    });
};

const generateImageWithAI = async (exercise: Exercise): Promise<string | null> => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
        
        const prompt = `Generate a schematic illustration for the fitness exercise named '${exercise.name}'.
Style requirements:
- **Style:** Clean, minimalist, schematic line drawing.
- **Background:** Pure white background (#FFFFFF).
- **Color:** Use only black lines for the figure. Use subtle, thin blue arrows to indicate the direction of movement.
- **Figure:** The figure must be anonymous, with no distinct gender features.
- **Safety:** CRITICAL: The posture must be anato mically correct and safe, showing the perfect form for the exercise. For squats or lunges, ensure the knee does not go excessively past the toes. For back exercises, ensure a neutral, straight spine.
- **Composition:** No text, no shadows, no background elements. Just the figure and movement arrows. The image should be clear and easy to understand at a small size.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: prompt }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                return part.inlineData.data; // This is the base64 string
            }
        }
        return null;
    } catch (error) {
        console.error(`AI image generation failed for "${exercise.name}":`, error);
        return null;
    }
};


// --- Request Queue System to manage API rate limits ---

const MAX_CONCURRENT_REQUESTS = 3; // Keep this low to avoid rate limiting
let activeRequests = 0;

const requestQueue: {
  exercise: Exercise;
  resolve: (value: string | null) => void;
  reject: (reason?: any) => void;
}[] = [];

const pendingPromises = new Map<string, Promise<string | null>>();

async function processQueue() {
  if (activeRequests >= MAX_CONCURRENT_REQUESTS || requestQueue.length === 0) {
    return;
  }

  activeRequests++;
  const { exercise, resolve, reject } = requestQueue.shift()!;

  try {
    const generatedImage = await generateImageWithAI(exercise);
    if (generatedImage) {
      await saveImageToCache(exercise.id, generatedImage);
      resolve(generatedImage);
    } else {
      // Resolve with null to indicate generation failure, which the UI can handle.
      resolve(null);
    }
  } catch (error) {
    console.error(`Error processing queue for exercise ${exercise.id}:`, error);
    reject(error);
  } finally {
    // Clean up and process next item
    pendingPromises.delete(exercise.id);
    activeRequests--;
    processQueue();
  }
}

const getImageForExercise = async (exercise: Exercise): Promise<string | null> => {
  // 1. Check IndexedDB cache first.
  const cachedImage = await getImageFromCache(exercise.id);
  if (cachedImage) {
    return cachedImage;
  }

  // 2. If not in cache, check if a request is already pending in the queue.
  if (pendingPromises.has(exercise.id)) {
    return pendingPromises.get(exercise.id)!;
  }

  // 3. If no request is pending, create a new promise and add it to the queue.
  const promise = new Promise<string | null>((resolve, reject) => {
    requestQueue.push({ exercise, resolve, reject });
  });
  
  pendingPromises.set(exercise.id, promise);

  // 4. Trigger the queue processor.
  processQueue();

  return promise;
};


export const imageCacheService = {
  getImageForExercise,
};