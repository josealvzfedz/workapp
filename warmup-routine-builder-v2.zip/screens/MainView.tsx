import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Exercise, RoutineExercise, ExerciseType } from '../types';
import { exerciseService } from '../services/exerciseService';
import AddExerciseModal from '../components/AddExerciseModal';
import WorkoutScreen from './WorkoutScreen';
import Tag from '../components/Tag';
import { useTranslation } from '../i18n';
import { calculateTotalExerciseTimeSeconds, formatTime } from '../utils';
import useDebounce from '../hooks/useDebounce';
import AIExerciseImage from '../components/AIExerciseImage';

// Icons
const PencilIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path d="M2.695 14.763l-1.262 3.154a.5.5 0 0 0 .65.65l3.155-1.262a4 4 0 0 0 1.343-.885L17.5 5.5a2.121 2.121 0 0 0-3-3L3.58 13.42a4 4 0 0 0-.885 1.343Z" />
  </svg>
);

const TrashIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M8.75 1A2.75 2.75 0 0 0 6 3.75v.443c-.795.077-1.58.177-2.365.298a.75.75 0 1 0 .23 1.482l.149-.022.841 10.518A2.75 2.75 0 0 0 7.596 19h4.807a2.75 2.75 0 0 0 2.742-2.53l.841-10.52.149.023a.75.75 0 0 0 .23-1.482A41.03 41.03 0 0 0 14 4.193v-.443A2.75 2.75 0 0 0 11.25 1h-2.5ZM10 4c.84 0 1.673.025 2.5.075V3.75c0-.69-.56-1.25-1.25-1.25h-2.5c-.69 0-1.25.56-1.25 1.25v.325C8.327 4.025 9.16 4 10 4ZM8.58 7.72a.75.75 0 0 0-1.5.06l.3 7.5a.75.75 0 1 0 1.5-.06l-.3-7.5Zm4.34.06a.75.75 0 1 0-1.5-.06l-.3 7.5a.75.75 0 1 0 1.5.06l.3-7.5Z" clipRule="evenodd" />
  </svg>
);

const PlusIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path d="M10.75 4.75a.75.75 0 0 0-1.5 0v4.5h-4.5a.75.75 0 0 0 0 1.5h4.5v4.5a.75.75 0 0 0 1.5 0v-4.5h4.5a.75.75 0 0 0 0-1.5h-4.5v-4.5Z" />
  </svg>
);

const Bars3Icon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
  </svg>
);

const generateId = () => `id_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

const MainView: React.FC = () => {
  const { t, language } = useTranslation(); 

  const [userCustomExercises, setUserCustomExercises] = useState<Exercise[]>(() => {
    const saved = localStorage.getItem('userCustomExercises');
    return saved ? JSON.parse(saved) : [];
  });

  const [todayRoutine, setTodayRoutine] = useState<RoutineExercise[]>(() => {
    const saved = localStorage.getItem('todayRoutine');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [allExercises, setAllExercises] = useState<Exercise[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearchQuery = useDebounce(searchQuery, 300);
  
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [showAddExerciseModal, setShowAddExerciseModal] = useState<boolean>(false);
  const [showWorkoutPlayer, setShowWorkoutPlayer] = useState<boolean>(false);
  
  const [editingExercise, setEditingExercise] = useState<Exercise | null>(null);
  const [isEditModeForModal, setIsEditModeForModal] = useState<boolean>(false);
  const [editingRoutineItemId, setEditingRoutineItemId] = useState<string | null>(null);

  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);

  useEffect(() => {
    const loadExercises = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const exercises = await exerciseService.getAllExercises(userCustomExercises, language);
        setAllExercises(exercises);
      } catch (err) {
        setError(t('errorLoadingExercises'));
      } finally {
        setIsLoading(false);
      }
    };
    loadExercises();
  }, [userCustomExercises, t, language]);

  const filteredExercises = useMemo(() => {
    const keywords = debouncedSearchQuery
      .toLowerCase()
      .trim()
      .split(/\s+/)
      .filter(Boolean);

    if (keywords.length === 0) {
      return allExercises;
    }

    return allExercises.filter(ex => {
      const searchableText = [
        ex.name,
        ex.equipment,
        ex.level,
        ...(ex.primaryMuscles || []),
        ...(ex.secondaryMuscles || []),
      ].join(' ').toLowerCase();

      return keywords.every(keyword => searchableText.includes(keyword));
    });
  }, [debouncedSearchQuery, allExercises]);


  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem('userCustomExercises', JSON.stringify(userCustomExercises));
  }, [userCustomExercises]);

  useEffect(() => {
    localStorage.setItem('todayRoutine', JSON.stringify(todayRoutine));
  }, [todayRoutine]);

  const totalRoutineTime = useMemo(() => {
    return todayRoutine.reduce((total, exercise) => {
      return total + calculateTotalExerciseTimeSeconds(exercise);
    }, 0);
  }, [todayRoutine]);
  
  const handleDrop = () => {
    if (dragItem.current === null || dragOverItem.current === null) return;
    
    const newRoutine = [...todayRoutine];
    const draggedItemContent = newRoutine.splice(dragItem.current, 1)[0];
    newRoutine.splice(dragOverItem.current, 0, draggedItemContent);
    
    dragItem.current = null;
    dragOverItem.current = null;

    setTodayRoutine(newRoutine);
  };

  const handleSaveExercise = useCallback((
    exerciseData: Omit<Exercise, 'id' | 'name' | 'description'> & { name: string, description?: string },
    originalIdIfEditing?: string
  ) => {
      // Context 1: Editing an item from the "Today's Routine" list
      if (editingRoutineItemId) {
        setTodayRoutine(prev => 
            prev.map(item => 
                item.routineItemId === editingRoutineItemId
                    ? { ...item, ...exerciseData }
                    : item
            )
        );
    } 
    // Context 2: Editing a custom exercise from the Library
    else if (originalIdIfEditing) {
        setUserCustomExercises(prev => 
            prev.map(ex => 
                ex.id === originalIdIfEditing ? { ...ex, ...exerciseData } : ex
            )
        );
        // Also update any instances of this exercise in the routine to reflect the change
        setTodayRoutine(prevRoutine => prevRoutine.map(item => 
            item.id === originalIdIfEditing ? { ...item, ...exerciseData } : item
        ));
    } 
    // Context 3: Adding a new custom exercise to the Library
    else {
        const newCustomExercise: Exercise = {
            ...exerciseData,
            id: generateId(),
        };
        setUserCustomExercises(prev => [...prev, newCustomExercise]);
    }
  }, [editingRoutineItemId]);

  const handleOpenEditModal = useCallback((exercise: Exercise) => {
    setEditingExercise(exercise);
    setIsEditModeForModal(true);
    setShowAddExerciseModal(true);
    setEditingRoutineItemId(null); // Clear routine edit context
  }, []);
  
  const handleOpenEditRoutineItemModal = useCallback((routineItem: RoutineExercise) => {
    setEditingExercise(routineItem);
    setIsEditModeForModal(true);
    setShowAddExerciseModal(true);
    setEditingRoutineItemId(routineItem.routineItemId); // Set routine edit context
  }, []);

  const handleDeleteCustomExercise = useCallback((exerciseIdToDelete: string) => {
    setUserCustomExercises(prev => prev.filter(ex => ex.id !== exerciseIdToDelete));
    // Also remove from current routine if it exists there
    setTodayRoutine(prevRoutine => prevRoutine.filter(item => item.id !== exerciseIdToDelete));
  }, []);

  const handleAddToRoutine = useCallback((exerciseToAdd: Exercise) => {
    const newRoutineItem: RoutineExercise = {
      ...exerciseToAdd,
      routineItemId: generateId(),
    };
    setTodayRoutine(prev => [...prev, newRoutineItem]);
  }, []);

  const handleRemoveFromRoutine = useCallback((routineItemIdToRemove: string) => {
    setTodayRoutine(prev => prev.filter(item => item.routineItemId !== routineItemIdToRemove));
  }, []);

  const handleResetRoutine = useCallback(() => {
    setTodayRoutine([]);
  }, []);

  const startWorkout = () => {
    if (todayRoutine.length > 0) {
      setShowWorkoutPlayer(true);
    }
  };
  
  const finishWorkout = () => {
    setShowWorkoutPlayer(false);
  };

  const renderExerciseList = () => {
    if (isLoading) {
        return (
            <div className="flex justify-center items-center py-10">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600"></div>
                <p className="ml-3 text-slate-500">{t('loadingExercisesMessage')}</p>
            </div>
        );
    }
    if (error) {
        return <p className="italic text-red-500 py-4 text-center">{error}</p>;
    }
    if (filteredExercises.length > 0) {
        return (
            <ul className="space-y-3">
              {filteredExercises.map(ex => {
                const isCustom = !ex.id.startsWith('pd_') && !ex.id.startsWith('db_');
                return (
                  <li key={ex.id} className="flex items-center p-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors duration-150 ease-in-out gap-4">
                    <div className="w-20 h-20 bg-slate-200 rounded-md flex-shrink-0 overflow-hidden border border-slate-200">
                        <AIExerciseImage exercise={ex} />
                    </div>
                    <div className="flex-grow truncate pr-2">
                      <p className="font-semibold text-slate-800 truncate" title={ex.name}>{ex.name}</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {ex.primaryMuscles?.[0] && <Tag type="muscle" text={ex.primaryMuscles[0]} />}
                        {ex.equipment && <Tag type="equipment" text={ex.equipment} />}
                        {ex.level && <Tag type="level" text={ex.level} />}
                      </div>
                    </div>
                    <div className="flex items-center space-x-1 sm:space-x-2 flex-shrink-0">
                        {isCustom && (
                          <>
                            <button
                                onClick={() => handleOpenEditModal(ex)}
                                className="p-1.5 text-amber-500 hover:text-amber-700 hover:bg-amber-100 rounded-full transition-colors"
                                aria-label={t('editButtonLabel')}
                                title={t('editButtonLabel')}
                            >
                               <PencilIcon />
                            </button>
                            <button
                                onClick={() => handleDeleteCustomExercise(ex.id)}
                                className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-100 rounded-full transition-colors"
                                aria-label={t('deleteExerciseButtonLabel')}
                                title={t('deleteExerciseButtonLabel')}
                            >
                               <TrashIcon />
                            </button>
                          </>
                        )}
                        <button 
                            onClick={() => handleAddToRoutine(ex)} 
                            className="p-1.5 text-sky-500 hover:text-sky-700 hover:bg-sky-100 rounded-full transition-colors"
                            aria-label={t('addToRoutineButton')}
                            title={t('addToRoutineButton')}
                        >
                            <PlusIcon className="w-5 h-5"/>
                        </button>
                    </div>
                  </li>
                );
              })}
            </ul>
        );
    }
    return <p className="italic text-slate-500 py-4 text-center">{t('noExercisesFoundMessage')}</p>;
  };


  if (showWorkoutPlayer) {
    return <WorkoutScreen 
      routine={todayRoutine} 
      onFinishWorkout={finishWorkout} 
      onGoBack={finishWorkout}
    />;
  }

  // MainView UI
  return (
    <div className="p-4">
      <h1 className="text-3xl sm:text-4xl font-bold mb-8 text-sky-800 text-center">{t('mainTitle')}</h1>
      
      {/* Section 1: "Rutina de Hoy" */}
      <section className="mb-8 p-4 sm:p-6 border border-slate-200 rounded-xl bg-white shadow-md">
        <div className="flex justify-between items-center mb-3">
            <h2 className="text-xl font-semibold text-sky-600">{t('currentRoutineSectionTitle')}</h2>
            {todayRoutine.length > 0 && (
                <span className="text-sm font-medium text-slate-500">
                {t('totalRoutineTimeLabel')}: {formatTime(totalRoutineTime)}
                </span>
            )}
        </div>
        
        {todayRoutine.length === 0 ? (
          <p className="italic text-slate-500 py-4 text-center">{t('emptyRoutineMessage')}</p>
        ) : (
          <ul className="space-y-2 mb-4 max-h-72 overflow-y-auto pr-1">
            {todayRoutine.map((ex, index) => (
              <li 
                key={ex.routineItemId} 
                className="flex justify-between items-center p-2 bg-slate-50 hover:bg-slate-100 rounded-md transition-colors"
                draggable
                onDragStart={() => dragItem.current = index}
                onDragEnter={() => dragOverItem.current = index}
                onDragEnd={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                >
                <div className="flex items-center flex-grow truncate">
                    <span className="cursor-grab text-slate-400 p-1 mr-2" aria-label={t('dragHandleLabel')}>
                        <Bars3Icon className="w-5 h-5" />
                    </span>
                    <span className="font-medium text-slate-700 truncate pr-2">{index + 1}. {ex.name}</span>
                </div>
                
                <div className="flex items-center space-x-1 flex-shrink-0">
                    <button
                        onClick={() => handleOpenEditRoutineItemModal(ex)}
                        className="p-1.5 text-amber-500 hover:text-amber-700 hover:bg-amber-100 rounded-full transition-colors"
                        aria-label={t('editButtonLabel')}
                        title={t('editButtonLabel')}
                    >
                        <PencilIcon className="w-4 h-4" />
                    </button>
                    <button 
                        onClick={() => handleRemoveFromRoutine(ex.routineItemId)} 
                        className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-100 rounded-full transition-colors"
                        aria-label={t('removeFromRoutineButtonLabel')}
                        title={t('removeFromRoutineButtonLabel')}
                    >
                        <TrashIcon className="w-4 h-4" />
                    </button>
                </div>
              </li>
            ))}
          </ul>
        )}
         <div className="flex flex-col sm:flex-row gap-3 mt-4">
            <button 
            onClick={startWorkout}
            disabled={todayRoutine.length === 0}
            className="flex-1 px-5 py-3 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-md disabled:bg-slate-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 mr-2"><path fillRule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clipRule="evenodd" /></svg>
                {t('startRoutineButton')}
            </button>
            <button 
                onClick={handleResetRoutine} 
                disabled={todayRoutine.length === 0}
                className="flex-1 px-5 py-3 bg-rose-500 text-white rounded-md hover:bg-rose-600 disabled:bg-slate-400 transition-colors font-medium flex items-center justify-center"
            >
                {t('resetRoutineButton')}
            </button>
        </div>
      </section>

      {/* Section 2: "Biblioteca de Ejercicios" */}
      <section className="mb-6 p-4 sm:p-6 border border-slate-200 rounded-xl bg-white shadow-md">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-sky-600">{t('exerciseLibrarySectionTitle')}</h2>
            <button 
            onClick={() => {
                setIsEditModeForModal(false);
                setEditingExercise(null);
                setShowAddExerciseModal(true);
            }}
            className="px-4 py-2 bg-emerald-500 text-white rounded-md hover:bg-emerald-600 transition-colors font-medium flex items-center text-sm"
            >
            <PlusIcon className="w-5 h-5 mr-2" />
            {t('addCustomExerciseButton')}
            </button>
        </div>
        
        <div className="mb-4">
            <input
                type="text"
                placeholder={t('searchExercisePlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-3 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
            />
        </div>

        <div className="max-h-96 overflow-y-auto pr-1">
          {renderExerciseList()}
        </div>
      </section>
      
      <AddExerciseModal
        isOpen={showAddExerciseModal}
        onClose={() => {
            setShowAddExerciseModal(false);
            setEditingExercise(null);
            setIsEditModeForModal(false);
            setEditingRoutineItemId(null);
        }}
        onSaveExercise={handleSaveExercise}
        isEditMode={isEditModeForModal}
        exerciseToEdit={editingExercise}
      />
    </div>
  );
};

export default MainView;