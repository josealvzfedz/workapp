import React from 'react';
import { useTranslation } from '../i18n';

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onGetStarted }) => {
  const { t } = useTranslation();

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] text-center">
      <div className="bg-white p-8 sm:p-12 rounded-xl shadow-xl max-w-lg w-full">
        <img 
          src="https://storage.googleapis.com/gemini-ui-params/fuchsia-common%2Fhero_3_shapes.svg" 
          alt={t('welcomeTitle')} 
          className="w-40 h-40 mx-auto mb-8" 
        />
        <h1 className="text-4xl sm:text-5xl font-bold text-sky-600 mb-4">
          {t('welcomeTitle')}
        </h1>
        <p className="text-slate-600 mb-10 text-lg px-4">
          {t('welcomeSubtitle')}
        </p>
        <button
          onClick={onGetStarted}
          className="w-full max-w-xs px-8 py-4 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-150 ease-in-out text-xl focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-opacity-75"
        >
          {t('getStarted')}
        </button>
        <p className="text-xs text-slate-400 mt-10">
          {t('welcomeTerms')}
        </p>
      </div>
    </div>
  );
};

export default WelcomeScreen;