import React, { useState, useEffect, useRef, useCallback, useReducer } from 'react';
import { RoutineExercise, ExerciseType } from '../types';
import { formatTime } from '../utils';
import { useTranslation } from '../i18n';
import AIExerciseImage from '../components/AIExerciseImage';

// Icons
const StopIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M4.5 7.5a3 3 0 0 1 3-3h9a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3h-9a3 3 0 0 1-3-3v-9Z" clipRule="evenodd" />
  </svg>
);
const BackArrowIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
  </svg>
);
const PauseIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path fillRule="evenodd" d="M6.75 5.25a.75.75 0 0 1 .75-.75H9a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H7.5a.75.75 0 0 1-.75-.75V5.25Zm7.5 0A.75.75 0 0 1 15 4.5h1.5a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H15a.75.75 0 0 1-.75-.75V5.25Z" clipRule="evenodd" /></svg>
);
const PlayIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path fillRule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clipRule="evenodd" /></svg>
);
const SkipIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
  </svg>
);
const SpeakerWaveIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 0 1 0 12.728M16.463 8.288a5.25 5.25 0 0 1 0 7.424M6.75 8.25l4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75Z" />
  </svg>
);

const SpeakerXMarkIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75 19.5 12m0 0 2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-7.5-6.75h.008v.008H9.75v-.008Zm0 0c0 .004 0 .008 0 .012L7.006 12l2.744 2.259c.004 0 .008.004.012.004L12 14.25l2.244.759c.004-.001.008-.004.012-.004L16.994 12 14.25 9.741c-.004-.004-.008-.008-.012-.012L12 7.5l-2.244.759Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.875 18.75C13.538 18.521 13.175 18.25 12.75 18H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75l4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-.284.574Z" />
  </svg>
);


interface WorkoutScreenProps {
  routine: RoutineExercise[];
  onFinishWorkout: () => void;
  onGoBack: () => void;
}

enum WorkoutPhase {
  GET_READY = 'GET_READY',
  WORKING = 'WORKING',
  RESTING_BETWEEN_REPS = 'RESTING_BETWEEN_REPS',
  COMPLETED = 'COMPLETED'
}

const ALARM_SOUND_URL = 'https://www.soundjay.com/button/sounds/button-7.mp3';
const PREP_COUNTDOWN_SECONDS = 5;

// --- State Management using useReducer ---

interface WorkoutState {
  routine: RoutineExercise[];
  currentExerciseIndex: number;
  currentRep: number;
  phase: WorkoutPhase;
  timeLeftInPhase: number;
  isPaused: boolean;
}

type WorkoutAction = { type: 'TICK' } | { type: 'TOGGLE_PAUSE' } | { type: 'SKIP' };

const initWorkoutState = (routine: RoutineExercise[]): WorkoutState => {
  return {
    routine,
    currentExerciseIndex: 0,
    currentRep: 1,
    phase: routine.length > 0 ? WorkoutPhase.GET_READY : WorkoutPhase.COMPLETED,
    timeLeftInPhase: routine.length > 0 ? PREP_COUNTDOWN_SECONDS : 0,
    isPaused: false,
  };
};

function workoutReducer(state: WorkoutState, action: WorkoutAction): WorkoutState {
  switch (action.type) {
    case 'TOGGLE_PAUSE':
      return { ...state, isPaused: !state.isPaused };
    case 'SKIP': {
      const nextExerciseIdx = state.currentExerciseIndex + 1;
      if (nextExerciseIdx >= state.routine.length) {
        return { ...state, phase: WorkoutPhase.COMPLETED, timeLeftInPhase: 0 };
      }

      const newCurrentEx = state.routine[nextExerciseIdx];
      return {
        ...state,
        currentExerciseIndex: nextExerciseIdx,
        currentRep: 1,
        phase: WorkoutPhase.WORKING,
        timeLeftInPhase: newCurrentEx.duration,
      };
    }
    case 'TICK': {
      if (state.isPaused || state.phase === WorkoutPhase.COMPLETED) {
        return state;
      }
      if (state.timeLeftInPhase > 1) {
        return { ...state, timeLeftInPhase: state.timeLeftInPhase - 1 };
      }

      // Time is up, transition to the next phase.
      const { phase, currentExerciseIndex, currentRep, routine } = state;

      if (phase === WorkoutPhase.GET_READY) {
        const firstEx = routine[0];
        return {
          ...state,
          phase: WorkoutPhase.WORKING,
          timeLeftInPhase: firstEx.duration,
          currentExerciseIndex: 0,
          currentRep: 1,
        };
      }

      const currentEx = routine[currentExerciseIndex];

      if (currentEx.type === ExerciseType.REPETITIVE) {
        if (phase === WorkoutPhase.WORKING) {
          if (currentRep < currentEx.reps && currentEx.restBetweenReps > 0) {
            return { ...state, phase: WorkoutPhase.RESTING_BETWEEN_REPS, timeLeftInPhase: currentEx.restBetweenReps };
          } else {
            const nextRep = currentRep + 1;
            if (nextRep <= currentEx.reps) {
              return { ...state, currentRep: nextRep, timeLeftInPhase: currentEx.duration };
            }
          }
        } else if (phase === WorkoutPhase.RESTING_BETWEEN_REPS) {
          const nextRep = currentRep + 1;
          return { ...state, currentRep: nextRep, phase: WorkoutPhase.WORKING, timeLeftInPhase: currentEx.duration };
        }
      }

      const nextExerciseIdx = currentExerciseIndex + 1;
      if (nextExerciseIdx >= routine.length) {
        return { ...state, phase: WorkoutPhase.COMPLETED, timeLeftInPhase: 0 };
      }

      const newCurrentEx = routine[nextExerciseIdx];
      return {
        ...state,
        currentExerciseIndex: nextExerciseIdx,
        currentRep: 1,
        phase: WorkoutPhase.WORKING,
        timeLeftInPhase: newCurrentEx.duration,
      };
    }
    default:
      return state;
  }
}

const WorkoutScreen: React.FC<WorkoutScreenProps> = ({ routine, onFinishWorkout, onGoBack }) => {
  const { t } = useTranslation();
  const [state, dispatch] = useReducer(workoutReducer, routine, initWorkoutState);
  const { currentExerciseIndex, currentRep, phase, timeLeftInPhase, isPaused } = state;

  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);
  const [isDescriptionModalOpen, setIsDescriptionModalOpen] = useState(false);
  
  const timerIdRef = useRef<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const prevPhaseRef = useRef(phase);
  
  const currentActiveExercise = routine[currentExerciseIndex];

  useEffect(() => {
    audioRef.current = new Audio(ALARM_SOUND_URL);
    if (audioRef.current) {
        audioRef.current.preload = 'auto';
    }
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = isAudioMuted;
    }
  }, [isAudioMuted]);

  const playAlarm = useCallback(() => {
    if (isAudioMuted || !audioRef.current) return;
    audioRef.current.currentTime = 0;
    audioRef.current.play().catch(error => console.warn("Audio play failed:", error));
  }, [isAudioMuted]);

  // Main Timer Effect
  useEffect(() => {
    if (isPaused || phase === WorkoutPhase.COMPLETED) {
      if (timerIdRef.current) {
        clearInterval(timerIdRef.current);
        timerIdRef.current = null;
      }
      return;
    }

    timerIdRef.current = window.setInterval(() => {
      dispatch({ type: 'TICK' });
    }, 1000);

    return () => {
      if (timerIdRef.current) {
        clearInterval(timerIdRef.current);
      }
    };
  }, [isPaused, phase]);

  // Sound Effect for countdowns
  useEffect(() => {
    if (isAudioMuted || isPaused) return;
    const shouldBeepForCountdown =
      (phase === WorkoutPhase.GET_READY && timeLeftInPhase >= 1 && timeLeftInPhase <= 4) ||
      ((phase === WorkoutPhase.WORKING || phase === WorkoutPhase.RESTING_BETWEEN_REPS) && timeLeftInPhase >= 1 && timeLeftInPhase <= 3);
    
    if (shouldBeepForCountdown) {
      playAlarm();
    }
  }, [timeLeftInPhase, phase, isPaused, isAudioMuted, playAlarm]);

  // Sound effect for phase transitions
  useEffect(() => {
    const prevPhase = prevPhaseRef.current;
    if (prevPhase !== phase) {
      if (!isAudioMuted && (phase === WorkoutPhase.WORKING || phase === WorkoutPhase.COMPLETED)) {
        playAlarm();
      }
      prevPhaseRef.current = phase;
    }
  }, [phase, isAudioMuted, playAlarm]);
  
  if (phase === WorkoutPhase.COMPLETED || routine.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] bg-white p-6 rounded-xl shadow-xl">
        <h2 className="text-3xl font-bold text-sky-600 mb-4">
          {routine.length > 0 ? t('workoutCompletedTitle') : t('emptyRoutineTitleWorkout')}
        </h2>
        <p className="text-slate-600 text-lg mb-6">
          {routine.length > 0 ? t('workoutCompletedMessage') : t('emptyRoutineMessageWorkout')}
        </p>
        <button
          onClick={onGoBack}
          className="mt-6 px-8 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all text-lg"
        >
          {t('backToMainScreenButton')}
        </button>
      </div>
    );
  }

  if (phase === WorkoutPhase.GET_READY) {
    const firstExerciseName = routine.length > 0 ? routine[0].name : '';
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] bg-white p-6 sm:p-8 rounded-xl shadow-xl max-w-2xl mx-auto text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-sky-600 mb-4">{t('getReady')}</h2>
        <div className="text-9xl font-bold tabular-nums text-sky-500 my-4" aria-live="off">
          {timeLeftInPhase}
        </div>
        <p className="text-xl font-medium text-slate-600 h-8">
          {t('firstExercise', { exerciseName: firstExerciseName })}
        </p>
        <div className="mt-8 flex justify-center items-center space-x-6">
          <button
            onClick={onGoBack}
            className="px-6 py-3 bg-slate-100 text-slate-600 hover:bg-slate-200 rounded-lg font-medium flex items-center transition-colors"
          >
            <BackArrowIcon className="w-5 h-5 mr-2" />
            {t('goBackButtonLabel')}
          </button>
        </div>
      </div>
    );
  }
  
  let phaseDisplayString = "";
  if (currentActiveExercise) {
    if (phase === WorkoutPhase.WORKING) {
      phaseDisplayString = currentActiveExercise.type === ExerciseType.REPETITIVE ? 
        t('phaseWorkRep', { currentRep: currentRep, totalReps: currentActiveExercise.reps}) : 
        t('phaseWorking');
    } else if (phase === WorkoutPhase.RESTING_BETWEEN_REPS) {
      phaseDisplayString = t('phaseRestingRep', { currentRep: currentRep, totalReps: currentActiveExercise.reps});
    }
  }

  const togglePause = () => dispatch({ type: 'TOGGLE_PAUSE' });
  const toggleMute = () => setIsAudioMuted(!isAudioMuted);

  return (
    <>
      <div className="bg-white p-6 sm:p-8 rounded-xl shadow-xl max-w-2xl mx-auto">
        <div className="relative flex justify-between items-center mb-8">
          <button
            onClick={onGoBack}
            className="p-2 text-sky-500 hover:text-sky-700 hover:bg-sky-100 rounded-full transition-colors"
            aria-label={t('goBackButtonLabel')}
          >
            <BackArrowIcon />
          </button>
          <h2 className="text-2xl sm:text-3xl font-bold text-sky-600 text-center flex-grow truncate px-2" title={t('workoutInProgressTitle')}>
            {t('workoutInProgressTitle')}
          </h2>
          <button
            onClick={toggleMute}
            className="p-2 text-slate-500 hover:text-sky-600 rounded-full hover:bg-slate-100 transition-colors"
            aria-label={isAudioMuted ? t('unmuteButtonLabel') : t('muteButtonLabel')}
            title={isAudioMuted ? t('unmuteButtonLabel') : t('muteButtonLabel')}
          >
            {isAudioMuted ? <SpeakerXMarkIcon /> : <SpeakerWaveIcon />}
          </button>
        </div>

        {currentActiveExercise && (
          <div className="space-y-5 text-center">
            <h3 className="text-3xl sm:text-4xl font-semibold text-slate-800 mb-3" aria-live="polite">{currentActiveExercise.name}</h3>
            
            <div className="relative w-full aspect-video bg-slate-100 rounded-lg flex items-center justify-center my-4 border border-slate-200 overflow-hidden">
              <AIExerciseImage exercise={currentActiveExercise} />
            </div>

            <div className="text-8xl font-bold tabular-nums text-sky-500 my-4" aria-live="off">
              {formatTime(timeLeftInPhase)}
            </div>
      
            <p className="text-xl font-medium text-slate-600 h-8" aria-live="polite">
              {phaseDisplayString}
            </p>
      
            <div className="text-slate-500 mt-2 px-4 min-h-[6rem] text-left">
                {currentActiveExercise.description && (
                  <>
                    <p style={{
                        overflow: 'hidden',
                        display: '-webkit-box',
                        WebkitBoxOrient: 'vertical',
                        // @ts-ignore
                        WebkitLineClamp: 3,
                    }}>
                        {currentActiveExercise.description}
                    </p>
                    {currentActiveExercise.description.length > 150 && (
                        <button 
                            onClick={() => setIsDescriptionModalOpen(true)}
                            className="text-sky-600 hover:text-sky-800 font-medium text-sm mt-2"
                        >
                            {t('readMore')}
                        </button>
                    )}
                  </>
                )}
            </div>
      
            <p className="text-sm text-slate-400 mt-4">
              {t('exerciseOutOf', {currentIndexPlusOne: currentExerciseIndex + 1, totalExercises: routine.length})}
            </p>

            <div className="mt-8 flex justify-center items-center space-x-4 sm:space-x-6">
              <button
                  onClick={onFinishWorkout}
                  className="px-5 py-2.5 bg-rose-100 text-rose-600 hover:bg-rose-200 rounded-lg font-medium flex items-center transition-colors text-sm"
                  aria-label={t('stopAndFinishButton')}
                  title={t('stopAndFinishButton')}
              >
                  <StopIcon className="w-5 h-5" />
              </button>
              <button
                  onClick={togglePause}
                  className="w-20 h-20 bg-sky-500 hover:bg-sky-600 text-white rounded-full flex items-center justify-center shadow-lg transform hover:scale-105 transition-all"
                  aria-label={isPaused ? t('resumeButtonLabel') : t('pauseButtonLabel')}
              >
                  {isPaused ? <PlayIcon className="w-10 h-10" /> : <PauseIcon className="w-10 h-10" />}
              </button>
              <button
                  onClick={() => dispatch({ type: 'SKIP' })}
                  className="p-3 bg-slate-100 text-slate-600 hover:bg-slate-200 rounded-full transition-colors"
                  aria-label={t('skipButtonLabel')}
                  title={t('skipButtonLabel')}
              >
                  <SkipIcon className="w-6 h-6"/>
              </button>
            </div>
          </div>
        )}
      </div>
      
      {isDescriptionModalOpen && (
            <div 
                className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50 transition-opacity duration-300 ease-in-out"
                onClick={() => setIsDescriptionModalOpen(false)}
            >
                <div 
                    className="bg-white p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-lg max-h-[80vh] flex flex-col transform transition-all duration-300 ease-in-out"
                    onClick={(e) => e.stopPropagation()}
                >
                    <div className="flex justify-between items-center mb-4 flex-shrink-0">
                        <h2 className="text-2xl font-semibold text-sky-600">{t('exerciseDescriptionModalTitle')}</h2>
                        <button
                            onClick={() => setIsDescriptionModalOpen(false)}
                            className="text-slate-500 hover:text-sky-600 transition-colors p-1 rounded-full hover:bg-slate-100"
                            aria-label={t('closeModalButtonLabel')}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-7 h-7">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                    <div className="overflow-y-auto pr-2 text-slate-700 text-left flex-grow">
                        <p className="whitespace-pre-wrap">{currentActiveExercise?.description}</p>
                    </div>
                    <div className="mt-6 flex justify-end flex-shrink-0">
                        <button
                            onClick={() => setIsDescriptionModalOpen(false)}
                            className="px-6 py-2.5 rounded-md text-white bg-sky-500 hover:bg-sky-600 transition-colors font-medium"
                        >
                            {t('closeButton')}
                        </button>
                    </div>
                </div>
            </div>
        )}
    </>
  );
};

export default WorkoutScreen;