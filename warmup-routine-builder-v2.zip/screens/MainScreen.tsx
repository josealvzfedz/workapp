
import React, { useState } from 'react';
// Fix: Removed LocalizedString as it's not exported and the app uses string for exercise names.
import { Exercise, ExerciseType, RoutineExercise } from '../types';
import AddExerciseModal from '../components/AddExerciseModal';
import { calculateTotalExerciseTimeSeconds, formatTime } from '../utils';
import { useTranslation } from '../i18n';

// Icons (can be moved to a dedicated icons file if they grow)
const PlusIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path d="M10.75 4.75a.75.75 0 0 0-1.5 0v4.5h-4.5a.75.75 0 0 0 0 1.5h4.5v4.5a.75.75 0 0 0 1.5 0v-4.5h4.5a.75.75 0 0 0 0-1.5h-4.5v-4.5Z" />
  </svg>
);

const TrashIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M8.75 1A2.75 2.75 0 0 0 6 3.75v.443c-.795.077-1.58.177-2.365.298a.75.75 0 1 0 .23 1.482l.149-.022.841 10.518A2.75 2.75 0 0 0 7.596 19h4.807a2.75 2.75 0 0 0 2.742-2.53l.841-10.52.149.023a.75.75 0 0 0 .23-1.482A41.03 41.03 0 0 0 14 4.193v-.443A2.75 2.75 0 0 0 11.25 1h-2.5ZM10 4c.84 0 1.673.025 2.5.075V3.75c0-.69-.56-1.25-1.25-1.25h-2.5c-.69 0-1.25.56-1.25 1.25v.325C8.327 4.025 9.16 4 10 4ZM8.58 7.72a.75.75 0 0 0-1.5.06l.3 7.5a.75.75 0 1 0 1.5-.06l-.3-7.5Zm4.34.06a.75.75 0 1 0-1.5-.06l-.3 7.5a.75.75 0 1 0 1.5.06l.3-7.5Z" clipRule="evenodd" />
  </svg>
);

const PlayIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clipRule="evenodd" />
  </svg>
);

interface MainScreenProps {
  routine: RoutineExercise[];
  userCustomExercises: Exercise[];
  allAvailableExercises: Exercise[];
  onAddCustomExercise: (exerciseData: Omit<Exercise, 'id' | 'name' | 'description'> & { name: string, description?: string }) => void;
  onAddToRoutine: (exerciseId: string) => void;
  onRemoveFromRoutine: (routineItemId: string) => void;
  onResetRoutine: () => void;
  onStartWorkout: () => void;
}

const MainScreen: React.FC<MainScreenProps> = ({
  routine,
  allAvailableExercises,
  onAddCustomExercise,
  onAddToRoutine,
  onRemoveFromRoutine,
  onResetRoutine,
  onStartWorkout,
}) => {
  const [selectedExerciseId, setSelectedExerciseId] = useState<string>('');
  const [showAddExerciseModal, setShowAddExerciseModal] = useState<boolean>(false);
  // Fix: Removed unused 'language' variable.
  const { t } = useTranslation();

  // Fix: Changed function to work with string names, consistent with Exercise type.
  const getExerciseName = (name: string) => name;

  const getExerciseDisplayInfo = (ex: Exercise) => {
    const totalTime = calculateTotalExerciseTimeSeconds(ex);
    let details = `${t('exerciseDetailTotal')}: ${formatTime(totalTime)}`;
    if (ex.type === ExerciseType.REPETITIVE) {
      details += ` (${ex.reps} ${t('exerciseDetailReps')}, ${ex.duration}${t('exerciseDetailDurationPerRep')}`;
      if (ex.restBetweenReps > 0) {
        details += `, ${ex.restBetweenReps}${t('exerciseDetailRestPerRep')}`;
      }
      details += `)`;
    }
    return details;
  };


  return (
    <div className="space-y-8">
      <AddExerciseModal
        isOpen={showAddExerciseModal}
        onClose={() => setShowAddExerciseModal(false)}
        onSaveExercise={onAddCustomExercise}
      />
      
      <header className="text-center mb-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-sky-600">
          {t('mainTitle')}
        </h1>
        <p className="text-slate-500 mt-1 text-lg">{t('mainSubtitle')}</p>
      </header>

      {/* Section 1: Add Exercises */}
      <section className="p-6 bg-white rounded-xl shadow-lg">
        <h2 className="text-xl font-semibold mb-5 text-sky-700">{t('addExercisesSectionTitle')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="md:col-span-2">
            <label htmlFor="exerciseSelect" className="block text-sm font-medium text-slate-600 mb-1">{t('selectExerciseLabel')}</label>
            <select
              id="exerciseSelect"
              value={selectedExerciseId}
              onChange={(e) => setSelectedExerciseId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
            >
              <option value="">{t('selectExercisePlaceholder')}</option>
              {allAvailableExercises.map(ex => (
                <option key={ex.id} value={ex.id}>
                  {getExerciseName(ex.name)} ({getExerciseDisplayInfo(ex)})
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={() => {
              onAddToRoutine(selectedExerciseId);
              setSelectedExerciseId(''); 
            }}
            disabled={!selectedExerciseId}
            className="w-full md:w-auto flex items-center justify-center px-5 py-3 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-md disabled:bg-slate-400 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 transition-all duration-150 ease-in-out"
          >
            <PlusIcon className="mr-2" /> {t('addToRoutineButton')}
          </button>
        </div>
        <div className="mt-5 text-center md:text-left">
          <button
            onClick={() => setShowAddExerciseModal(true)}
            className="px-5 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-medium rounded-md inline-flex items-center transform hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 transition-all duration-150 ease-in-out"
          >
            <PlusIcon className="mr-2" /> {t('addCustomExerciseButton')}
          </button>
        </div>
      </section>

      {/* Section 2: Current Routine */}
      <section className="p-6 bg-white rounded-xl shadow-lg">
        <h2 className="text-xl font-semibold mb-5 text-sky-700">{t('currentRoutineSectionTitle')}</h2>
        {routine.length === 0 ? (
          <p className="text-slate-500 italic">{t('emptyRoutineMessage')}</p>
        ) : (
          <ul className="space-y-3 max-h-96 overflow-y-auto pr-2 border border-slate-200 rounded-md p-3">
            {routine.map((item, index) => (
              <li
                key={item.routineItemId}
                className="flex justify-between items-center p-3 rounded-md bg-slate-50 hover:bg-slate-100 transition-colors duration-150 ease-in-out"
              >
                <div>
                  <span className="font-medium text-slate-700">{index + 1}. {getExerciseName(item.name)}</span>
                  <span className="ml-2 text-xs text-slate-500">
                     ({getExerciseDisplayInfo(item)})
                  </span>
                </div>
                <button
                  onClick={() => onRemoveFromRoutine(item.routineItemId)}
                  className="p-1.5 text-rose-500 hover:text-rose-700 rounded-full hover:bg-rose-100 transition-all duration-150 ease-in-out"
                  aria-label={t('resetRoutineButton')} // A bit generic, ideally "Remove exercise..."
                >
                  <TrashIcon className="w-4 h-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-6 flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
          <button
            onClick={onStartWorkout}
            disabled={routine.length === 0}
            className="w-full flex items-center justify-center px-6 py-3 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-md disabled:bg-slate-400 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-150 ease-in-out"
          >
            <PlayIcon className="mr-2" /> {t('startRoutineButton')}
          </button>
          <button
            onClick={onResetRoutine}
            disabled={routine.length === 0}
            className="w-full flex items-center justify-center px-6 py-3 bg-rose-500 hover:bg-rose-600 text-white font-medium rounded-md disabled:bg-slate-400 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2 transition-all duration-150 ease-in-out"
          >
            {t('resetRoutineButton')}
          </button>
        </div>
      </section>
    </div>
  );
};

export default MainScreen;
