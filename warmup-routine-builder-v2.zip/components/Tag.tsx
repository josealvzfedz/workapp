import React from 'react';

type TagType = 'muscle' | 'equipment' | 'level' | 'default';

interface TagProps {
  type: TagType;
  text: string;
}

const Tag: React.FC<TagProps> = ({ type, text }) => {
  const baseClasses = "text-xs font-semibold mr-2 px-2.5 py-0.5 rounded-full capitalize";

  const typeClasses = {
    muscle: 'bg-blue-100 text-blue-800',
    equipment: 'bg-green-100 text-green-800',
    level: 'bg-amber-100 text-amber-800',
    default: 'bg-slate-100 text-slate-800',
  };

  const className = `${baseClasses} ${typeClasses[type] || typeClasses.default}`;

  return (
    <span className={className}>
      {text}
    </span>
  );
};

export default Tag;
