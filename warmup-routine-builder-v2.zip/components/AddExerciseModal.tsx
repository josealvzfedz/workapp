

import React, { useState, useEffect, useMemo } from 'react';
import { Exercise, ExerciseType } from '../types';
import { DEFAULT_EXERCISE_FORM_STATE } from '../constants';
import { calculateTotalExerciseTimeSeconds, formatTime } from '../utils';
import { useTranslation } from '../i18n';
import { GoogleGenAI, Type } from '@google/genai';
import { translationService } from '../services/translationService';

interface AddExerciseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveExercise: (
    exerciseData: Omit<Exercise, 'id' | 'name' | 'description'> & { name: string, description?: string },
    originalIdIfEditing?: string
  ) => void;
  isEditMode?: boolean;
  exerciseToEdit?: Exercise | null;
}

const AddExerciseModal: React.FC<AddExerciseModalProps> = ({ 
  isOpen, 
  onClose, 
  onSaveExercise, 
  isEditMode = false, 
  exerciseToEdit = null 
}) => {
  const [formState, setFormState] = useState(DEFAULT_EXERCISE_FORM_STATE);
  const [error, setError] = useState<string | null>(null);
  const { t, language } = useTranslation();
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Effect to set initial form state
  useEffect(() => {
    if (isOpen) {
      if (isEditMode && exerciseToEdit) {
        setFormState({
          name: exerciseToEdit.name,
          type: exerciseToEdit.type,
          duration: String(exerciseToEdit.duration),
          reps: String(exerciseToEdit.reps),
          restBetweenReps: String(exerciseToEdit.restBetweenReps),
          description: exerciseToEdit.description || '',
        });
      } else {
        setFormState(DEFAULT_EXERCISE_FORM_STATE);
      }
      // Reset errors on open
      setError(null);
      setAiError(null);
    }
  }, [isOpen, isEditMode, exerciseToEdit]);

  const calculatedTime = useMemo(() => {
    const duration = parseInt(formState.duration, 10);
    const reps = parseInt(formState.reps, 10);
    const restBetweenReps = parseInt(formState.restBetweenReps, 10);

    return calculateTotalExerciseTimeSeconds({
      type: formState.type as ExerciseType,
      duration: isNaN(duration) ? 0 : duration,
      reps: isNaN(reps) ? 0 : reps,
      restBetweenReps: isNaN(restBetweenReps) ? 0 : restBetweenReps,
    });
  }, [formState]);

  const handleGenerateWithAI = async () => {
    if (!formState.name.trim()) return;

    setIsGenerating(true);
    setAiError(null);
    setError(null);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

        const schema = {
            type: Type.OBJECT,
            properties: {
                description: {
                    type: Type.STRING,
                    description: 'A detailed but concise description on how to perform the exercise, in English.',
                },
                type: {
                    type: Type.STRING,
                    enum: [ExerciseType.BLOCK, ExerciseType.REPETITIVE],
                    description: `The type of exercise. Use '${ExerciseType.REPETITIVE}' for exercises counted in reps, and '${ExerciseType.BLOCK}' for exercises counted in seconds.`
                },
                duration: {
                    type: Type.INTEGER,
                    description: `For '${ExerciseType.REPETITIVE}' type, the duration of a single repetition in seconds. For '${ExerciseType.BLOCK}' type, the total duration in seconds. Should be appropriate for a warm-up.`,
                },
                reps: {
                    type: Type.INTEGER,
                    description: `For '${ExerciseType.REPETITIVE}' type, the recommended number of repetitions for a warm-up. For '${ExerciseType.BLOCK}' type, this should always be 1.`,
                },
                restBetweenReps: {
                    type: Type.INTEGER,
                    description: `For '${ExerciseType.REPETITIVE}' type, the rest time in seconds between each repetition. For '${ExerciseType.BLOCK}' type, this should always be 0.`,
                },
            },
            required: ['description', 'type', 'duration', 'reps', 'restBetweenReps'],
        };

        const prompt = `Based on the exercise name "${formState.name}", generate a detailed description in English of how to perform it correctly. Also, suggest if it is a "block" or "repetitive" type of exercise, and provide an appropriate duration, number of reps, and rest time between reps suitable for a warmup routine. For a "block" exercise, reps should be 1 and restBetweenReps should be 0.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
              responseMimeType: 'application/json',
              responseSchema: schema,
            },
        });
        const resultJson = response.text;
        let parsedResult = JSON.parse(resultJson);

        if (parsedResult.description && language !== 'en') {
          const translatedDescription = await translationService.translate(parsedResult.description, language);
          parsedResult.description = translatedDescription;
        }

        setFormState(prev => ({
            ...prev,
            description: parsedResult.description || '',
            type: parsedResult.type === 'repetitive' ? ExerciseType.REPETITIVE : ExerciseType.BLOCK,
            duration: String(parsedResult.duration || 30),
            reps: String(parsedResult.reps || 1),
            restBetweenReps: String(parsedResult.restBetweenReps || 0),
        }));

    } catch (e) {
        console.error("Gemini generation failed:", e);
        setAiError(t('errorAIGeneration'));
    } finally {
        setIsGenerating(false);
    }
  };

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formState.name.trim()) {
      setError(t('errorNameRequired'));
      return;
    }

    const duration = parseInt(formState.duration, 10);
    const reps = parseInt(formState.reps, 10);
    const restBetweenReps = parseInt(formState.restBetweenReps, 10);

    if (formState.type === ExerciseType.BLOCK) {
      if (isNaN(duration) || duration <= 0) {
        setError(t('errorDurationBlockPositive'));
        return;
      }
    } else if (formState.type === ExerciseType.REPETITIVE) {
      if (isNaN(duration) || duration <= 0) {
        setError(t('errorDurationRepPositive'));
        return;
      }
      if (isNaN(reps) || reps <= 0) {
        setError(t('errorRepsPositive'));
        return;
      }
      if (isNaN(restBetweenReps) || restBetweenReps < 0) {
        setError(t('errorRestPositive'));
        return;
      }
    }
    
    onSaveExercise({
      name: formState.name.trim(),
      type: formState.type as ExerciseType,
      duration: duration,
      reps: formState.type === ExerciseType.REPETITIVE ? reps : 1,
      restBetweenReps: formState.type === ExerciseType.REPETITIVE ? restBetweenReps : 0,
      description: formState.description?.trim() || undefined,
    }, isEditMode && exerciseToEdit ? exerciseToEdit.id : undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50 transition-opacity duration-300 ease-in-out">
      <div className="bg-white p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto transform transition-all duration-300 ease-in-out scale-100">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold text-sky-600">
            {isEditMode ? t('editCustomExerciseModalTitle') : t('addCustomExerciseModalTitle')}
          </h2>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-sky-600 transition-colors p-1 rounded-full hover:bg-slate-100"
            aria-label={t('closeModalButtonLabel')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-7 h-7">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        {error && <div className="mb-4 p-3 bg-red-100 text-red-700 border border-red-300 rounded-md">{error}</div>}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* ... existing form fields for name, type, duration, reps, rest ... */}
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">{t('exerciseNameLabel')} <span className="text-red-500">*</span></label>
            <input
              type="text"
              name="name"
              id="name"
              value={formState.name}
              onChange={handleChange}
              className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-2.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
              required
            />
          </div>

          <div>
            <label htmlFor="type" className="block text-sm font-medium text-slate-700 mb-1">{t('exerciseTypeLabel')} <span className="text-red-500">*</span></label>
            <select
              name="type"
              id="type"
              value={formState.type}
              onChange={handleChange}
              className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-2.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
            >
              <option value={ExerciseType.BLOCK}>{t('exerciseTypeBlockOption')}</option>
              <option value={ExerciseType.REPETITIVE}>{t('exerciseTypeRepetitiveOption')}</option>
            </select>
          </div>

          {formState.type === ExerciseType.BLOCK && (
            <div>
              <label htmlFor="duration" className="block text-sm font-medium text-slate-700 mb-1">{t('durationLabel')} <span className="text-red-500">*</span></label>
              <input
                type="number"
                name="duration"
                id="duration"
                value={formState.duration}
                onChange={handleChange}
                min="1"
                className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-2.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
                required
              />
            </div>
          )}

          {formState.type === ExerciseType.REPETITIVE && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="duration" className="block text-sm font-medium text-slate-700 mb-1">{t('durationPerRepLabel')} <span className="text-red-500">*</span></label>
                  <input
                    type="number"
                    name="duration"
                    id="duration"
                    value={formState.duration}
                    onChange={handleChange}
                    min="1"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-2.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="reps" className="block text-sm font-medium text-slate-700 mb-1">{t('repsLabel')} <span className="text-red-500">*</span></label>
                  <input
                    type="number"
                    name="reps"
                    id="reps"
                    value={formState.reps}
                    onChange={handleChange}
                    min="1"
                    className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-2.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
                    required
                  />
                </div>
              </div>
              <div>
                <label htmlFor="restBetweenReps" className="block text-sm font-medium text-slate-700 mb-1">{t('restBetweenRepsLabel')} <span className="sm text-slate-500">{t('restBetweenRepsHelper')}</span></label>
                <input
                  type="number"
                  name="restBetweenReps"
                  id="restBetweenReps"
                  value={formState.restBetweenReps}
                  onChange={handleChange}
                  min="0"
                  className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-2.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
                  required
                />
              </div>
            </>
          )}
          
          <div className="mt-3 p-3 bg-sky-50 border border-sky-200 rounded-md text-center">
            <p className="text-sm font-medium text-sky-700">{t('calculatedTotalTimeLabel')} 
              <span className="font-bold text-lg ml-2">{formatTime(calculatedTime)}</span>
            </p>
          </div>
           
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center space-x-2">
                <label htmlFor="description" className="block text-sm font-medium text-slate-700">{t('descriptionLabel')}</label>
              </div>
              <button
                type="button"
                onClick={handleGenerateWithAI}
                disabled={!formState.name.trim() || isGenerating}
                className="flex items-center px-3 py-1.5 text-xs font-medium text-sky-700 bg-sky-100 rounded-md hover:bg-sky-200 disabled:bg-slate-200 disabled:text-slate-500 disabled:cursor-not-allowed transition-colors"
              >
                {isGenerating ? (
                    <>
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-sky-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        {t('generating')}
                    </>
                ) : (
                    <>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0V6H3a1 1 0 110-2h1V3a1 1 0 011-1zm6.5.5a.5.5 0 00-1 0v2.5a.5.5 0 001 0V2.5zM9 6a.5.5 0 000-1h2.5a.5.5 0 000-1H9zM11.5 5.5a.5.5 0 00-1 0v2.5a.5.5 0 001 0V5.5z" clipRule="evenodd" />
                          <path fillRule="evenodd" d="M3 10a1 1 0 011 1v1h1a1 1 0 110 2H4v1a1 1 0 11-2 0v-1H1a1 1 0 110-2h1v-1a1 1 0 011-1zm10.5-.5a.5.5 0 01.5.5v2.5a.5.5 0 01-1 0V10a.5.5 0 01.5-.5zM13 14a.5.5 0 01.5.5v2.5a.5.5 0 01-1 0V14.5a.5.5 0 01.5-.5z" clipRule="evenodd" />
                        </svg>
                        {t('generateWithAI')}
                    </>
                )}
              </button>
            </div>
            <textarea
              name="description"
              id="description"
              value={formState.description}
              onChange={handleChange}
              rows={3}
              className="w-full bg-slate-50 border border-slate-300 text-slate-700 rounded-md p-2.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors resize-none"
            />
             {aiError && <p className="text-xs text-red-500 mt-1">{aiError}</p>}
          </div>

          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-md text-slate-700 bg-slate-200 hover:bg-slate-300 transition-colors font-medium"
            >
              {t('cancelButton')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-md text-white bg-sky-500 hover:bg-sky-600 transition-colors font-medium flex items-center"
            >
              {isEditMode ? 
                (<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5 mr-2"><path d="M2.695 14.763l-1.262 3.154a.5.5 0 0 0 .65.65l3.155-1.262a4 4 0 0 0 1.343-.885L17.5 5.5a2.121 2.121 0 0 0-3-3L3.58 13.42a4 4 0 0 0-.885 1.343Z" /></svg>) :
                (<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5 mr-2"><path d="M10.75 4.75a.75.75 0 0 0-1.5 0v4.5h-4.5a.75.75 0 0 0 0 1.5h4.5v4.5a.75.75 0 0 0 1.5 0v-4.5h4.5a.75.75 0 0 0 0-1.5h-4.5v-4.5Z" /></svg>)
              }
              {isEditMode ? t('saveChangesButton') : t('addExerciseButtonModal')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddExerciseModal;
